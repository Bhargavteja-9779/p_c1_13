Submission package - Ophthalmology and Therapy (Original Research)
Title: How Early Can Glaucoma Visual-Field Progression Be Detected Without False Alarms?
       A Benchmark With True No-Change Calibration
Authors: P N Bhargav Teja; Rajay Vedaraj I S (corresponding, rajay@vit.ac.in), Vellore Institute of Technology (VIT), Vellore

01_Manuscript             Final_Manuscript.docx (upload this; line-numbered, double-spaced, tables after references)
02_Cover_Letter           Cover_Letter.docx
03_Figures                Fig1-Fig5 as TIFF and JPG (300 dpi) + Figure_Legends.txt
04_Supplementary_Material Supplementary_Material.docx (S1 development history, S2-S7 extra tables)
05_Code_and_Data          code (bash code/reproduce.sh), results (per-eye outputs, statistics), tables, manuscript_build

Optional before submitting: add department/school names to the affiliation and suggested reviewers in the cover letter.
