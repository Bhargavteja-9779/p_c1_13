Submission package - Ophthalmology and Therapy (Original Research)
Title: How Early Can Glaucoma Visual-Field Progression Be Detected Without False Alarms?
       A Benchmark With True No-Change Calibration
Authors: P N Bhargav Teja; [SECOND AUTHOR NAME] (corresponding), Vellore Institute of Technology (VIT), Vellore

01_Manuscript             Final_Manuscript.docx (upload this; line-numbered, double-spaced, tables after references)
02_Cover_Letter           Cover_Letter.docx
03_Figures                Fig1-Fig5 as TIFF and JPG (300 dpi) + Figure_Legends.txt
04_Supplementary_Material Supplementary_Material.docx (S1 development history, S2-S7 extra tables)
05_Code_and_Data          code (bash code/reproduce.sh), results (per-eye outputs, statistics), tables, manuscript_build

BEFORE SUBMITTING, fill in: second author name, department(s), corresponding e-mail, date in the cover letter,
suggested reviewers (optional). Search the .docx files for "[" to find every placeholder.
